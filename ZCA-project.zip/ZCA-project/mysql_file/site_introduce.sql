INSERT INTO `site_introduce`(`name_site`, `introduce`) VALUES ('科技大学', '湖南科技大学是湖南省“国内一流大学建设高校”，是一所优秀的综合性大学，这里有很多优秀的老师，有美丽的校园风景。');
INSERT INTO `site_introduce`(`name_site`, `introduce`) VALUES ('湘潭大学', '湘潭大学简称“湘大”，是毛泽东同志亲自倡办的综合性全国重点大学。');
INSERT INTO `site_introduce`(`name_site`, `introduce`) VALUES ('火车站', '火车站指湘潭站，是中国铁路广州局集团有限公司管辖的二等站，是沪昆铁路的站点，长株潭城际铁路上的起始站。');
INSERT INTO `site_introduce`(`name_site`, `introduce`) VALUES ('科大御花苑', '科大御苑位于科大南堕和科大北门的交界处，很热闹。');
