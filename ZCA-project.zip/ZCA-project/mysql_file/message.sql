INSERT INTO `message`(`number`, `user_name`, `content`, `date_time`) VALUES (1, '小鸿', '系统做的不错', '2021.05.14');
INSERT INTO `message`(`number`, `user_name`, `content`, `date_time`) VALUES (2, '小文', '建议修改14路车发车时间间隔', '2021.05.17');
INSERT INTO `message`(`number`, `user_name`, `content`, `date_time`) VALUES (3, '小聪', '建议及时更新公交信息', '2021.05.17');
INSERT INTO `message`(`number`, `user_name`, `content`, `date_time`) VALUES (4, '小爱', '系统可以', '2021.05.18');
INSERT INTO `message`(`number`, `user_name`, `content`, `date_time`) VALUES (5, '小聪', 'good', '2021.05.18');
INSERT INTO `message`(`number`, `user_name`, `content`, `date_time`) VALUES (6, '小文', 'nice', '2021.05.18');
