INSERT INTO `user`(`user_name`, `user_password`, `user_number`) VALUES ('小爱', '123789', '1234567891');
INSERT INTO `user`(`user_name`, `user_password`, `user_number`) VALUES ('小单', '123456', '15773283127');
INSERT INTO `user`(`user_name`, `user_password`, `user_number`) VALUES ('小芳', '123456', '17682458565');
INSERT INTO `user`(`user_name`, `user_password`, `user_number`) VALUES ('小富', '123456', '17682459532');
INSERT INTO `user`(`user_name`, `user_password`, `user_number`) VALUES ('小美', '123789', '17682459565');
INSERT INTO `user`(`user_name`, `user_password`, `user_number`) VALUES ('小文', '123789', '17624595641');
