INSERT INTO `notice`(`number`, `date`, `content`) VALUES (1, '2021.05.04', '新增了14路公交车路线');
INSERT INTO `notice`(`number`, `date`, `content`) VALUES (2, '2021.05.04', '14路公交线增加了站点赤马路口，其位于二十三冶之后一站');
INSERT INTO `notice`(`number`, `date`, `content`) VALUES (4, '2021.05.05', '公告查询和其管理做出来了');
INSERT INTO `notice`(`number`, `date`, `content`) VALUES (6, '2021.05.06', '系统首页完善了');
INSERT INTO `notice`(`number`, `date`, `content`) VALUES (7, '2021.05.07', '系统初步完成啦，欢迎大家使用，以后更改通知将会通过公告发出来');
