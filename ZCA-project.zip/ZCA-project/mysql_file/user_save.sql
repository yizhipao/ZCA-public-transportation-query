INSERT INTO `user_save`(`user_name`, `bus_name`, `sites`) VALUES ('小单', '107路', '科技大学 ->刺马路口 ->二十三冶 ->雨湖区武装部 ->桃园公寓 ->五医院 ->工贸中专 ->高岭路口 ->技师学院 ->湘大体育馆 ->公交停靠站 ->湘潭大学');
INSERT INTO `user_save`(`user_name`, `bus_name`, `sites`) VALUES ('小美', '14路', '二十三冶->赤马路口->科大御花苑->科技大学');
INSERT INTO `user_save`(`user_name`, `bus_name`, `sites`) VALUES ('小单', '28路', '赤马路口->科大御花苑->科技大学');
INSERT INTO `user_save`(`user_name`, `bus_name`, `sites`) VALUES ('小富', '14路', '技师学院 ->湘大体育馆 ->公交停靠站 ->湘潭大学');
