INSERT INTO `bus_information`(`bus_name`, `time_summer`, `price`, `interval_time`, `time_winter`) VALUES ('107路', '06:30-21:30', 2, '10', '06:30-21:30');
INSERT INTO `bus_information`(`bus_name`, `time_summer`, `price`, `interval_time`, `time_winter`) VALUES ('14路', '06:20-19:00', 3, '15', '06:20-19:00');
INSERT INTO `bus_information`(`bus_name`, `time_summer`, `price`, `interval_time`, `time_winter`) VALUES ('15路', '06:30-21:30', 2, '20', '06:20-19:00');
INSERT INTO `bus_information`(`bus_name`, `time_summer`, `price`, `interval_time`, `time_winter`) VALUES ('28路', '06:00-21:40', 2, '20', '06:20-21:30');
INSERT INTO `bus_information`(`bus_name`, `time_summer`, `price`, `interval_time`, `time_winter`) VALUES ('6路', '07:00-22:00', 2, '15', '07:00-21:30');
